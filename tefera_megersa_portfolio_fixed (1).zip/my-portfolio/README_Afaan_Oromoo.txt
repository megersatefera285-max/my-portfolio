# Tefera Megersa — Portfolio Website

Portfolio website built with HTML, CSS, and JavaScript. Modern dark theme with English and Afaan Oromoo text.

## Website akkamitti banaa (How to run)
1. Folder `tefera_megersa_portfolio` extract godhi.
2. Visual Studio Code keessatti bani, yookiin `index.html` browser keessatti bani.
3. Live Server extension fayyadamuu dandeessa.

## Profile photo akka mul'atu (IMPORTANT — sababaa hin mul'anne)
Sababaa profile hin mul'anne:
- Folder `images` fi file `profile.jpg` zip keessaa hin jiru ture.
- Amma folder `images` uumameera. Ati file profile.jpg kee keessa galchi.

Akkamitti photo galchita:
1. Photo kee ifaa ta'e filadhu (JPG yookiin PNG).
2. Folder `images` keessa galchi.
3. Maqaa isaatti `profile.jpg` jedhi (exact name).
4. Browser refresh godhi — photo hero area keessatti mul'ata.

Yoo PNG ta'e:
- JPG taasiitii `profile.jpg` jedhi, yookiin
- index.html keessatti `src="images/profile.png"` jijjiiri.

## Motion / Vibration effect (haala haaraa)
Profile photo irratti animation dabalameera:
- Soft floating motion (ol-gadi socho'a)
- Hover godhaa yoo ta'e vibration / shake effect qaba
- Size xiqqoo guddateera (mul'achuu akka danda'u)

## Odeeffannoo ati qabdu
- Display name: Tefera Megersa
- Email: megersatefera285@gmail.com
- GitHub: https://github.com/teferaofi250-creator

## Before publishing
- Photo kee desktop fi mobile irratti akka gaariitti mul'atu mirkaneessi.
- Project description sample ta'e dhugaa kee waliin jijjiiri.
- Internship / education dates sirreessi.
- Contact form email app bana; server hin qabu.

## Files
- `index.html` — page content
- `css/style.css` — responsive dark theme + profile motion
- `js/script.js` — mobile navigation, reveal effects, email draft
- `images/profile.jpg` — **YOUR PHOTO HERE** (add this file)
